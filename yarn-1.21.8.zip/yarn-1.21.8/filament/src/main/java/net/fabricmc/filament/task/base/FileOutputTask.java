package net.fabricmc.filament.task.base;

public abstract class FileOutputTask extends FilamentTask implements WithFileOutput {
}
